function dataJWS(){

function showTime() {
  var a_p = "";
  var today = new Date();
  var curr_hour = today.getHours();
  var curr_minute = today.getMinutes();
  var curr_second = today.getSeconds();
  if (curr_hour < 12) {
    a_p = "AM";
  } else {
    a_p = "PM";
  }
  if (curr_hour == 0) {
    curr_hour = 12;
  }
  if (curr_hour > 12) {
    curr_hour = curr_hour - 12;
  }
  curr_hour = checkTime(curr_hour);
  curr_minute = checkTime(curr_minute);
  curr_second = checkTime(curr_second);
  document.getElementById('clock').innerHTML=curr_hour + ":" + curr_minute + ":" +curr_second+ a_p;
}
setInterval(showTime, 1);


function checkTime(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
var date = new Date();
var day = date.getDate();
var month = date.getMonth();
var thisDay = date.getDay(),
thisDay = myDays[thisDay];
var yy = date.getYear();
var year = (yy < 1000) ? yy + 1900 : yy;
document.getElementById('tanggal1').innerHTML=thisDay + ', ' + day + ' ' + months[month] + ' ' + year;


var x = document.getElementById("demo");
const d = new Date();
const tempDate = new Date().toLocaleString('id-ID', {
  year: 'numeric', 
  month: 'long', 
  day: 'numeric',
  weekday: 'long', 
});
const tempTime = new Date().toLocaleTimeString('id-ID', {
  hour12: false
});

const tahun = d.getFullYear()
const bulan = d.getMonth()
const tanggal = d.getDate()

const hari = d.getDay()

const jam = d.getHours()
const menit = d.getMinutes()
const detik = d.getSeconds()

const obj = {

  date: tempDate,
  time: tempTime,

  thn : tahun,
  bln: bulan,
  tgl: tanggal,

  hri:hari,

  ja:jam,
  me:menit,
  det:detik
}
document.querySelector('#formTime').addEventListener('submit', (e) => {
  e.preventDefault();
  e.stopPropagation();
  console.log(hari)
  var win = obj.date.replace(/[, ]+/g, '-')

  var person={
    "tahun":obj.thn,
    "bulan":obj.bln,
    "tanggal":obj.tgl,

    "hari":obj.hri,

    "jam":obj.ja,
    "menit":obj.me,
    "detik":obj.det
  };
  var personJSONString=JSON.stringify(person); 


  window.location = `?date=${personJSONString}` 

  return 
})
//informasi
document.querySelector('#informasi').addEventListener('submit', (e) => {
  e.preventDefault()
  e.stopPropagation()
  var info1= document.getElementById("info1").value;

  //var kcptn= document.getElementById("kecepatan").value;

  const obj1 = {
    inf1:info1,
//    kcpt:kcptn
  }  
  var person1={
    "info1":obj1.inf1
  //  "kecepatan":obj1.kcpt
  }
  var person1JSONString=JSON.stringify(person1); 

  window.location = `?info=${person1JSONString}` 

  return 
});
document.querySelector('#kecepatan').addEventListener('submit', (e) => {
  e.preventDefault()
  e.stopPropagation()
  var kecepatan1= document.getElementById("kecepatanku").value;

  //var kcptn= document.getElementById("kecepatan").value;

  const obj1 = {
    kecepatan:kecepatan1,
//    kcpt:kcptn
  }  
  var person1={
    "kecepatan":obj1.kecepatan
  //  "kecepatan":obj1.kcpt
  }
  var person1JSONString=JSON.stringify(person1); 

  window.location = `?kecepatan=${person1JSONString}` 

  return 
});
}
